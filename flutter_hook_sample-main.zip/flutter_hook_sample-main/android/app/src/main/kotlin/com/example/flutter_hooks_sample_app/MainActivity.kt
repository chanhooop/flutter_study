package com.example.flutter_hooks_sample_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
